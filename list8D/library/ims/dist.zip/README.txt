Welcome to the IMS Basic LTI Playground

This has several different parts:

- lms.php - a simple IMS Basic LTI that can be use to test
Basic LTI Producers

- tool.php - a simple IMS Basic LTI Tool Producer - used to 
test consumers

- adlist - a complete application using IMS Basic LTI to implement
a multi-tenancy classified-ad application.  This has a full database
andan administrator interface to set keys.   The documentation for
this application is in adlist/index.htm

- cc.php - a very basic parser for an IMS Common Cartridge.

- The IMS Basic LTI client libraries used by all of these applications
in the ims-blti folder

/Chuck
www.dr-chuck.com

Wed Feb 24 11:43:37 GMT 2010
