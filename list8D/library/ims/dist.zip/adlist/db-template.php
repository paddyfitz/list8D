<?php
$MY_CONNECTION = mysql_connect("127.0.0.1","adsuser","adspassword");
mysql_select_db("ads");
?>
